SAE 15 - ANFR Explorer
site/      -> le site web (ouvrir site/index.html)
donnees/   -> données ANFR
notebook/  -> code Python / notebook Jupyter
docs/      -> cahier des charges, rapport
